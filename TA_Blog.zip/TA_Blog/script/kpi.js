// Sample data for the KPI card
const totalRevenue = 500;

// Select the KPI card container
const kpiCard = d3.select("#kpiCard");

// Append the total revenue value
kpiCard.append("div")
  .attr("class", "kpi-value")
  .text(totalRevenue);

// Append the label
kpiCard.append("div")
  .attr("class", "kpi-label")
  .text("Total Revenue");
