document.addEventListener("DOMContentLoaded", function() {
    var svg = d3.select("#chart-container"),
        width = +svg.style("width").replace("px", ""),
        height = +svg.attr("height");
  
    //Width and height of map
    var width = 960;
    var height = 500;
  
    var lowColor = '#a1d99b';
    var highColor = '#006d2c';
  
    // D3 Projection
    var projection = d3.geoAlbersUsa()
        .translate([width / 2, height / 2]) // translate to center of screen
        .scale([1000]); // scale things down so see entire US
  
    // Define path generator
    var path = d3.geoPath() // path generator that will convert GeoJSON to SVG paths
        .projection(projection); // tell path generator to use albersUsa projection
  
    // Create SVG element and append map to the SVG
    var svg = d3.select("#chart-container")
        .append("svg")
        .attr("width", width)
        .attr("height", height);
  
    // Load in my states data!
    Promise.all([
        d3.csv("data/statesdata.csv"),
        d3.json("data/us-states.json")
    ]).then(([data, json]) => {
        var dataArray = data.map(d => parseFloat(d.value));
        var minVal = d3.min(dataArray);
        var maxVal = d3.max(dataArray);
        var ramp = d3.scaleLinear().domain([minVal, maxVal]).range([lowColor, highColor]);
  
        // Loop through each state data value in the CSV file
        data.forEach(d => {
            // Grab State Name
            var dataState = d.state;
  
            // Grab data value
            var dataValue = parseFloat(d.value);
  
            // Find the corresponding state inside the GeoJSON
            var matchingState = json.features.find(state => state.properties.name === dataState);
  
            if (matchingState) {
                // Copy the data value into the GeoJSON
                matchingState.properties.value = dataValue;
            }
        });
  
        // Bind the data to the SVG and create one path per GeoJSON feature
        svg.selectAll("path")
            .data(json.features)
            .enter()
            .append("path")
            .attr("d", path)
            .style("stroke", "#fff")
            .style("stroke-width", "1")
            .style("fill", d => ramp(d.properties.value))
            .on("mouseover", showTooltip)
            .on("mouseout", hideTooltip);
  
        // Add a legend
        var legend = svg.append("g")
            .attr("class", "legend")
            .attr("transform", "translate(850, 20)");
  
        var legendRect = legend.append("rect")
            .attr("width", 20)
            .attr("height", 200)
            .style("fill", "url(#gradient)");
  
        var y = d3.scaleLinear()
            .range([200, 0])
            .domain([minVal, maxVal]);
  
        var yAxis = d3.axisRight(y);
  
        legend.append("g")
            .attr("class", "y axis")
            .call(yAxis);
  
        // Tooltip functions
        function showTooltip(event, d) {
            d3.select("#tooltip")
                .style("left", (event.pageX + 10) + "px")
                .style("top", (event.pageY - 20) + "px")
                .html(`<strong>${d.properties.name}</strong><br>Value: ${d.properties.value}`);
            
            d3.select("#tooltip").classed("hidden", false);
        }
  
        function hideTooltip() {
            d3.select("#tooltip").classed("hidden", true);
        }
    }).catch(error => {
        throw error;
    });
  });
  