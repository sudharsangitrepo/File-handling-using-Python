// Declare global variables
let svg, path, label, l, transition, currentMetric;

// Declare replay function
function replay() {
    document.getElementById("scatterplot").innerHTML = "";
    loadChart();
}

function loadChart() {
    // Load data asynchronously from driving.csv
    d3.csv("data/driving.csv").then(function(driving) {
        // Convert miles column to numbers and gas column to numbers
        driving.forEach(function(d) {
            d.miles = +d.miles;
            d.gas = +d.gas;
        });

        // Define length function
        const length = (path) => d3.create("svg:path").attr("d", path).node().getTotalLength();

        // Declare the chart dimensions and margins
        const width = 928;
        const height = 720;
        const marginTop = 20;
        const marginRight = 30;
        const marginBottom = 30;
        const marginLeft = 40;

        // Declare the positional encodings
        const x = d3.scaleLinear()
            .domain(d3.extent(driving, d => d.miles)).nice()
            .range([marginLeft, width - marginRight]);

        const y = d3.scaleLinear()
            .domain(d3.extent(driving, d => d.gas)).nice()
            .range([height - marginBottom, marginTop]);

        const line = d3.line()
            .curve(d3.curveCatmullRom)
            .x(d => x(d.miles))
            .y(d => y(d.gas));

        svg = d3.select("#scatterplot")
            .append("svg")
            .attr("width", width + 200) // Increase the width to accommodate the legend
            .attr("height", height)
            .attr("viewBox", [0, 0, width + 200, height]) // Adjust the viewBox accordingly
            .attr("style", "max-width: 100%; height: auto;");

        l = length(line(driving));

        path = svg.append("path")
            .datum(driving)
            .attr("fill", "none")
            .attr("stroke", "green")
            .attr("stroke-width", 2.5)
            .attr("stroke-linejoin", "round")
            .attr("stroke-linecap", "round")
            .attr("stroke-dasharray", `0,${l}`)
            .attr("d", line)
            .transition(transition)
            .duration(5000)
            .ease(d3.easeLinear)
            .attr("stroke-dasharray", `${l},${l}`);

        svg.append("g")
            .attr("transform", `translate(0,${height - marginBottom})`)
            .call(d3.axisBottom(x).ticks(width / 80))
            .call(g => g.select(".domain").remove())
            .call(g => g.selectAll(".tick line").clone()
                .attr("y2", -height)
                .attr("stroke-opacity", 0.1))
            .call(g => g.append("text")
                .attr("x", width - 4)
                .attr("y", -4)
                .attr("font-weight", "bold")
                .attr("text-anchor", "end")
                .attr("fill", "currentColor")
                .text("Revenue"));

        svg.append("g")
            .attr("transform", `translate(${marginLeft},0)`)
            .call(d3.axisLeft(y).ticks(null, "$.2f"))
            .call(g => g.select(".domain").remove())
            .call(g => g.selectAll(".tick line").clone()
                .attr("x2", width)
                .attr("stroke-opacity", 0.1))
            .call(g => g.select(".tick:last-of-type text").clone()
                .attr("x", 4)
                .attr("text-anchor", "start")
                .attr("font-weight", "bold")
                .text("Profit"));

        svg.append("g")
            .attr("fill", "white")
            .attr("stroke", "black")
            .attr("stroke-width", 2)
            .selectAll("circle")
            .data(driving)
            .join("circle")
            .attr("cx", d => x(d.miles))
            .attr("cy", d => y(d.gas))
            .attr("r", 3);

        label = svg.append("g")
            .attr("font-family", "sans-serif")
            .attr("font-size", 10)
            .selectAll()
            .data(driving)
            .join("text")
            .attr("transform", d => `translate(${x(d.miles)},${y(d.gas)})`)
            .attr("fill-opacity", 0)
            .text(d => d.year)
            .attr("stroke", "white")
            .attr("paint-order", "stroke")
            .attr("fill", "currentColor")
            .each(function(d) {
                const t = d3.select(this);
                switch (d.side) {
                    case "top": t.attr("text-anchor", "middle").attr("dy", "-0.7em"); break;
                    case "right": t.attr("dx", "0.5em").attr("dy", "0.32em").attr("text-anchor", "start"); break;
                    case "bottom": t.attr("text-anchor", "middle").attr("dy", "1.4em"); break;
                    case "left": t.attr("dx", "-0.5em").attr("dy", "0.32em").attr("text-anchor", "end"); break;
                }
            });

        label.transition(transition)
            .delay((d, i) => length(line(driving.slice(0, i + 1))) / l * (5000 - 125))
            .attr("fill-opacity", 1);

        // Add legend pane for selecting metrics
        const legendPane = svg.append("g")
            .attr("transform", `translate(${width + 10}, ${height / 12 - 30})`);

        const legendTexts = ['Revenue', 'Cost', 'Profit'];

        legendPane.selectAll("circle.legend-marker")
            .data(legendTexts)
            .enter().append("circle")
            .attr("class", "legend-marker")
            .attr("cx", 0)
            .attr("cy", (d, i) => i * 20)
            .attr("r", 5)
            .attr("fill", "green")
            .style("cursor", "pointer")
            .on("click", updateChart);

        legendPane.selectAll("text.legend-text")
            .data(legendTexts)
            .enter().append("text")
            .attr("class", "legend-text")
            .attr("x", 12)
            .attr("y", (d, i) => i * 20 + 5)
            .attr("fill", "currentColor")
            .style("cursor", "pointer")
            .text(d => d)
            .on("click", updateChart);

        function updateChart(selectedMetric) {
            // Update the chart based on the selected metric (Revenue, Cost, Profit)
            // You may need to modify the existing chart or create a new one based on the selected metric.
            currentMetric = selectedMetric;
            console.log("Selected Metric:", selectedMetric);
            // Add your logic to update the chart here
            // For example, you may want to update the color of the line based on the selected metric
            path.attr("stroke", getColor(selectedMetric));
        }

        function getColor(metric) {
            // Define colors for each metric
            const colorMap = {
                'Revenue': 'green',
                'Cost': 'blue',
                'Profit': 'red'
            };
            return colorMap[metric];
        }

        // Expose replay function globally
    });
}

loadChart();
